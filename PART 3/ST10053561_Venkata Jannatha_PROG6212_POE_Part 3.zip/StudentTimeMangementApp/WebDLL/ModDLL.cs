﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebDLL
{
    public class ModDLL
    {
        public string ModuleName { get; set; }
        public List<int> ModuleWeeks { get; set; }
        public int SelfStudyHr { get; set; }
    }
}
